<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductSold extends Model
{
    //
}
