@extends('appfarmer')

@section('title') Dashboard Petani @endsection

@section('body')

Welcome back, {{Auth::user()->name}}

@endsection