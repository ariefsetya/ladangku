<?php $__env->startSection('title'); ?> Produk Saya <?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<hr><div class="pull-right"><a class="addnew" href="<?php echo e(route('harvest.start-plant')); ?>">Mulai Penanaman</a></div>
<h1>Produk Saya</h1>
<hr>
<table class="table">
	<thead>
		<tr>
			<th>Produk</th>
			<th>Masa Penanaman</th>
			<th>Status</th>
			<th>Hasil</th>
			<th>Harga per Satuan</th>
			<th>Stok</th>
			<th>Terjual</th>
			<th>Profit</th>
		</tr>
	</thead>
	<tbody>
	<?php $__currentLoopData = $harvest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<tr>
			<td><?php echo e($data->product->name); ?></td>
			<td><?php echo e($data->plant_date." - ".($data->harvest_date!=null?$data->harvest_date:"saat ini")); ?></td>
			<td><?php echo e($data->harvest_status); ?></td>
			<td><?php echo e($data->harvest_amount." ".$data->units); ?></td>
			<td>Rp. <?php echo e(number_format($data->price_per_units)."/".$data->units); ?></td>
			<td><?php echo e($data->harvest_amount-\App\ProductSold::selectRaw('sum(amount)')->where('id_harvest',$data->id)->where('id_product',$data->id_product)->first()['sum(amount)'].' '.$data->units); ?></td>
			<td><?php echo e(\App\ProductSold::selectRaw('sum(amount)')->where('id_harvest',$data->id)->where('id_product',$data->id_product)->first()['sum(amount)'].' '.$data->units); ?></td>
			<td>Rp<?php echo e(number_format(\App\ProductSold::selectRaw('sum(profit)')->where('id_harvest',$data->id)->where('id_product',$data->id_product)->first()['sum(profit)'])); ?></td>
		</tr>		
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</tbody>
</table>

<?php echo $harvest->render(); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('appfarmer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>