<hr>
<strong>Data Produk</strong>
<hr>
<table class="table">
	<tr>
		<td style="width: 30%;">Nama Produk</td>
		<td><input required type="text" name="name" value="<?php echo e(isset($name) ? $name : ''); ?>" placeholder="Contoh : Beras"></td>
	</tr>
	<tr>
		<td>Harga Jual</td>
		<td><input required type="text" name="modal" value="<?php echo e(isset($modal) ? $modal : ''); ?>" placeholder="Contoh : 10000"></td>
	</tr>
	<tr>
		<td>Satuan</td>
		<td><input required type="text" name="units" value="<?php echo e(isset($units) ? $units : ''); ?>" placeholder="Contoh : liter"></td>
	</tr>
	<tr>
		<td>Deskripsi</td>
		<td><textarea required type="text" name="description" placeholder="Contoh : Beras hasil terbaik"><?php echo e(isset($description) ? $description : ''); ?></textarea></td>
	</tr>
	<tr>
		<td></td>
		<td><input type="submit" value="Simpan"></td>
	</tr>
</table>