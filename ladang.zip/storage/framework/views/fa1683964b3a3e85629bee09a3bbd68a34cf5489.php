<?php $__env->startSection('title'); ?> Dashboard Petani <?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

Welcome back, <?php echo e(Auth::user()->name); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('appfarmer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>