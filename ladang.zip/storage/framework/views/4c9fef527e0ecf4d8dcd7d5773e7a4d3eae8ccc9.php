<?php $__env->startSection('title'); ?> Semua Data Produk <?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<hr><div class="pull-right"><a class="addnew" href="<?php echo e(route('product.create')); ?>">Tambah Data Produk</a></div>
<h1>Semua Data Produk</h1>
<hr>
<table class="table">
	<thead>
		<tr>
			<th>Nama</th>
			<th>Modal</th>
			<th>Satuan</th>
			<th colspan="2">Action</th>
		</tr>
	</thead>
	<tbody>
	<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<tr>
			<td><?php echo e($data->name); ?></td>
			<td>Rp. <?php echo e(number_format($data->modal,0)); ?></td>
			<td><?php echo e($data->units); ?></td>
			<td><a class="button" href="<?php echo route('product.edit',[$data->id]); ?>">Ubah</a></td>
			<td><form method="POST" action="<?php echo route('product.destroy',[$data->id]); ?>">
				<input type="hidden" name="_method" value="DELETE"><?php echo e(csrf_field()); ?><input type="submit" class="delete" onclick="return confirm('Are you sure to delete product <?php echo e($data->name); ?>?')" value="Hapus"></form></td>
		</tr>		
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</tbody>
</table>

<?php echo $product->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('appadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>