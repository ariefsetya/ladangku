<?php $__env->startSection('title'); ?> Semua Data Petani <?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<hr><div class="pull-right"><a class="addnew" href="<?php echo e(route('farmer.create')); ?>">Tambah Data Petani</a></div>
<h1>Semua Data Petani</h1>
<hr>
<table class="table">
	<thead>
		<tr>
			<th>NIK</th>
			<th>Nama</th>
			<th>Nomor HP</th>
			<th>Alamat</th>
			<th colspan="2">Action</th>
		</tr>
	</thead>
	<tbody>
	<?php $__currentLoopData = $farmer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<tr>
			<td><?php echo e($data->nik); ?></td>
			<td><?php echo e($data->name); ?></td>
			<td><?php echo e($data->phone); ?></td>
			<td><?php echo e($data->address); ?></td>
			<td><a class="button" href="<?php echo route('farmer.edit',[$data->id]); ?>">Ubah</a></td>
			<td><form method="POST" action="<?php echo route('farmer.destroy',[$data->id]); ?>">
				<input type="hidden" name="_method" value="DELETE"><?php echo e(csrf_field()); ?><input type="submit" class="delete" onclick="return confirm('Are you sure to delete farmer <?php echo e($data->name); ?>?')" value="Hapus"></form></td>
		</tr>		
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</tbody>
</table>

<?php echo $farmer->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('appadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>