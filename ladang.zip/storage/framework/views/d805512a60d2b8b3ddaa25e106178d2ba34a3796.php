<hr>
<strong>Data Unit Konversi</strong>
<hr>
<table class="table">
	<tr>
		<td style="width: 30%;">Satuan Asal</td>
		<td><input required type="text" name="from_unit" value="<?php echo e(isset($from_unit) ? $from_unit : ''); ?>" placeholder="Contoh : kg"></td>
	</tr>
	<tr>
		<td>Satuan Tujuan</td>
		<td><input required type="text" name="to_unit" value="<?php echo e(isset($to_unit) ? $to_unit : ''); ?>" placeholder="Contoh : g"></td>
	</tr>
	<tr>
		<td>Jumlah Asal</td>
		<td><input required type="text" name="from_amount" value="<?php echo e(isset($from_amount) ? $from_amount : ''); ?>" placeholder="Contoh : 1"></td>
	</tr>
	<tr>
		<td>Jumlah Asal</td>
		<td><input required type="text" name="to_amount" value="<?php echo e(isset($to_amount) ? $to_amount : ''); ?>" placeholder="Contoh : 1000"></td>
	</tr>
	<tr>
		<td></td>
		<td><input type="submit" value="Simpan"></td>
	</tr>
</table>