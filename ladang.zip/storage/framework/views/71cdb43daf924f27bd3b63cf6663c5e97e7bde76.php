<?php $__env->startSection('title'); ?> Produk Saya <?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<hr><div class="pull-right"><a class="addnew" href="<?php echo e(route('harvest.my-product')); ?>">Produk Saya</a></div>
<h1>Data Bahan Pokok</h1>
<hr>
<form method="POST" action="<?php echo e(route('harvest.next-select-material',[$harvest->id])); ?>">
<?php echo e(csrf_field()); ?>

<table class="table">
	<thead>
		<tr>
			<th>Bahan Pokok</th>
			<th>Jumlah</th>
			<th>Satuan</th>
			<th>Harga per Satuan</th>
			<th>Harga Total</th>
		</tr>
	</thead>
	<tbody>
		<?php $i=0;?>
		<?php $__currentLoopData = $material; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<tr>
			<td><input type="hidden" id="id_material_<?php echo e($i); ?>" name="id_material[]" value="<?php echo e($key->id); ?>">
			<input type="text" readonly name="material[]" value="<?php echo e($key->name); ?>"></td>
			<td><input type="number" oninput="hitung(<?php echo e($i); ?>)" id="amount_<?php echo e($i); ?>" name="amount[]" value="" placeholder="Contoh : 10"></td>
			<td><input type="text" name="units[]" readonly value="<?php echo e($key->units); ?>" placeholder="Contoh : kg"></td>
			<td><input type="number" oninput="hitung(<?php echo e($i); ?>)" id="price_<?php echo e($i); ?>" name="price[]" value="" placeholder="Contoh : 10000"></td>
			<td><input type="number" readonly id="total_<?php echo e($i); ?>" name="total[]" value="0"></td>
		</tr>
		<?php $i++;?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		<tr>
			<td></td>
			<td></td>
			<td></td>
			<td></td>
			<td><input type="submit" value="Selanjutnya"></td>
		</tr>
	</tbody>
</table>
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<script type="text/javascript">
	$(".for_date").datepicker();
	$(".for_date").datepicker("option", "dateFormat", "dd MM yy");
	function hitung(id) {
		if($("#amount_"+id).val()!="" && $("#price_"+id).val()!=""){
			$("#total_"+id).val($("#amount_"+id).val()*$("#price_"+id).val());
		}
	}
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('appfarmer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>