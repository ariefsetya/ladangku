<?php $__env->startSection('title'); ?> Produk Saya <?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<hr>
<strong>Informasi</strong>
<hr>

<h1><?php echo e($message); ?></h1>

<hr>
<a style="width:47%;float:right;" class="button" href="<?php echo e(route('harvest.start-plant')); ?>">Mulai Penanaman</a>
<a style="width:47%;float:left;" class="addnew" href="<?php echo e(route('harvest.my-product')); ?>">Produk Saya</a>

<br>
<br>
<br>
<br>
<br>
<br>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('appfarmer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>