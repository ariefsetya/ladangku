<?php $__env->startSection('title'); ?> Tambah Data Bahan Pokok <?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<hr><div class="pull-right"><a class="addnew" href="<?php echo e(route('material.index')); ?>">Semua Data Bahan Pokok</a></div>
<h1>Tambah Data Bahan Pokok</h1>
<hr>
<form method="POST" action="<?php echo e(route('material.store')); ?>">
	<?php echo e(csrf_field()); ?>

	<?php echo $__env->make('admin.material._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('appadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>