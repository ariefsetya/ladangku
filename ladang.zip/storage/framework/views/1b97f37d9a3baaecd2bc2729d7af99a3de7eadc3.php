<?php $__env->startSection('title'); ?> Jual Hasil Panen <?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<hr><div class="pull-right"><a class="addnew" href="<?php echo e(route('harvest.start-plant')); ?>">Mulai Penanaman</a></div>
<h1>Jual Hasil Panen</h1>
<hr>
<table class="table">
	<thead>
		<tr>
			<th>Produk</th>
			<th>Masa Penanaman</th>
			<th>Stok</th>
			<th>Terjual</th>
			<th>Profit</th>
			<th>Action</th>
		</tr>
	</thead>
	<tbody>
	<?php $__currentLoopData = $harvest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<tr>
			<td><?php echo e($data->product->name); ?></td>
			<td><?php echo e($data->plant_date." - ".$data->harvest_date); ?></td>
			<td><?php echo e($data->harvest_amount-\App\ProductSold::selectRaw('sum(amount)')->where('id_harvest',$data->id)->where('id_product',$data->id_product)->first()['sum(amount)'].' '.$data->units); ?></td>
			<td><?php echo e(\App\ProductSold::selectRaw('sum(amount)')->where('id_harvest',$data->id)->where('id_product',$data->id_product)->first()['sum(amount)'].' '.$data->units); ?></td>
			<td>Rp<?php echo e(number_format(\App\ProductSold::selectRaw('sum(profit)')->where('id_harvest',$data->id)->where('id_product',$data->id_product)->first()['sum(profit)'])); ?></td>
			<td>
			<?php if(($data->harvest_amount-\App\ProductSold::selectRaw('sum(amount)')->where('id_harvest',$data->id)->where('id_product',$data->id_product)->first()['sum(amount)'])>0): ?>
			<a class="button" href="<?php echo e(route('harvest.sell-harvest-id',[$data->id])); ?>">Jual</a>
			<?php else: ?>
			Stok Habis
			<?php endif; ?></td>
		</tr>		
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</tbody>
</table>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('appfarmer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>