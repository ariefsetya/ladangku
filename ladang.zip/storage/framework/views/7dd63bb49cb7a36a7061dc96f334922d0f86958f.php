<hr>
<strong>Identitas Dasar</strong>
<hr>
<table class="table">
	<tr>
		<td style="width: 30%;">Nomor Identitas</td>
		<td><input required type="text" name="nik" value="<?php echo e(isset($nik) ? $nik : ''); ?>" placeholder="Contoh : 31750431xxxx"></td>
	</tr>
	<tr>
		<td>Nama</td>
		<td><input required type="text" name="name" value="<?php echo e(isset($name) ? $name : ''); ?>" placeholder="Contoh : John Doe"></td>
	</tr>
	<tr>
		<td>Alamat</td>
		<td><textarea required type="text" name="address" placeholder="Contoh : Jalan Raya Bogor No. 81A"><?php echo e(isset($address) ? $address : ''); ?></textarea></td>
	</tr>
</table><hr>
<strong>Info Akun</strong><hr>
<table class="table">
	<tr>
		<td style="width: 30%;">Nomor HP</td>
		<td><input required type="text" name="phone" value="<?php echo e(isset($phone) ? $phone : ''); ?>" placeholder="format : +628387xxxxx"></td>
	</tr>
	<tr>
		<td>PIN</td>
		<td><input required type="text" name="pin" value="<?php echo e(isset($pin) ? $pin : ''); ?>" minlength="4" maxlength="4" placeholder="Contoh: 1234"></td>
	</tr>
	<tr>
		<td></td>
		<td><input type="submit" value="Simpan"></td>
	</tr>
</table>