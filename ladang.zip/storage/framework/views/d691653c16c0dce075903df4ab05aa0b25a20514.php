<?php $__env->startSection('title'); ?> Tambah Data Petani <?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<hr><div class="pull-right"><a class="addnew" href="<?php echo e(route('farmer.index')); ?>">Semua Data Petani</a></div>
<h1>Tambah Data Petani</h1>
<hr>
<form method="POST" action="<?php echo e(route('farmer.store')); ?>">
	<?php echo e(csrf_field()); ?>

	<?php echo $__env->make('admin.farmer._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('appadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>