<?php $__env->startSection('title'); ?> Jual Hasil Panen <?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<hr><div class="pull-right"><a class="addnew" href="<?php echo e(route('harvest.my-product')); ?>">Produk Saya</a></div>
<h1>Jual Hasil Panen <?php echo e($harvest->product->name); ?></h1>
<hr>

<hr>
<strong>Data Produk</strong>
<hr>
<form method="POST" action="<?php echo e(route('harvest.next-sell-harvest-id',[$harvest->id])); ?>">
<?php echo e(csrf_field()); ?>

<table class="table" style="width:50%;">
	<tr>
		<td>Nama Produk</td>
		<td><?php echo e($harvest->product->name); ?></td>
	</tr>
	<tr>
		<td>Mulai Penanaman</td>
		<td><?php echo e(date_format(date_create($harvest->plant_date),"d F Y")); ?></td>
	</tr>
	<tr>
		<td>Panen</td>
		<td><?php echo e(date_format(date_create($harvest->harvest_date),"d F Y")); ?></td>
	</tr>
	<tr>
		<td>Harga per <?php echo e($harvest->units); ?></td>
		<td>Rp<?php echo e(number_format($harvest->price_per_units,0,",",".")); ?></td>
	</tr>
	<tr>
		<td>Stok <?php echo e($harvest->product->name); ?></td>
		<td><?php echo e($harvest->harvest_amount-\App\ProductSold::selectRaw('sum(amount)')->where('id_harvest',$harvest->id)->where('id_product',$harvest->id_product)->first()['sum(amount)']." ".$harvest->units); ?></td>
	</tr>
</table>
<table class="table">
	<tr>
		<td>Jumlah Penjualan</td>
		<td><input type="hidden" id="ppu" name="price_per_units" value="<?php echo e($harvest->price_per_units); ?>"><input type="hidden" name="id_product" value="<?php echo e($harvest->id_product); ?>"><input type="hidden" name="units" value="<?php echo e($harvest->units); ?>"><input type="hidden" name="id_harvest" value="<?php echo e($harvest->id); ?>"><input type="hidden" id="stok" name="stok" value="<?php echo e($harvest->harvest_amount-\App\ProductSold::selectRaw('sum(amount)')->where('id_harvest',$harvest->id)->where('id_product',$harvest->id_product)->first()['sum(amount)']); ?>"><input oninput="hitung()" id="amount" type="text" name="amount" style="width: 95%"><?php echo e($harvest->units); ?></td>
	</tr>
	<tr>
		<td>Harga Total</td>
		<td><input type="text" readonly id="price" name="price"></td>
	</tr>
	<tr>
		<td>Sisa Stok</td>
		<td><input type="text" readonly id="stoksisa" name="stoksisa"></td>
	</tr>
	<tr>
		<td></td>
		<td><input type="submit" value="Jual"></td>
	</tr>
</table>
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<script type="text/javascript">
function hitung() {
	if($("#ppu").val()!="" && $("#amount").val()!=""){
		$("#price").val($("#ppu").val()*$('#amount').val());
		if(parseInt($("#stok").val())<parseInt($("#amount").val())){
			alert('Stok tidak mencukupi');
			$("#price").val('0');
			$("#amount").val('0');
		}
		$("#stoksisa").val(parseInt($("#stok").val())-parseInt($("#amount").val())+' <?php echo e($harvest->units); ?>');
	}else{
		$("#stoksisa").val(parseInt($("#stok").val())+' <?php echo e($harvest->units); ?>');
		$("#price").val('0');
		$("#amount").val('');
	}
}
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('appfarmer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>