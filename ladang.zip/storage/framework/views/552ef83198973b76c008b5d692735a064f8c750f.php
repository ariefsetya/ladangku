<hr>
<strong>Data Bahan Pokok</strong>
<hr>
<table class="table">
	<tr>
		<td style="width: 30%;">Nama Bahan Pokok</td>
		<td><input required type="text" name="name" value="<?php echo e(isset($name) ? $name : ''); ?>" placeholder="Contoh : Bibit Padi"></td>
	</tr>
	<tr>
		<td>Supplier</td>
		<td><input required type="text" name="supplier" value="<?php echo e(isset($supplier) ? $supplier : ''); ?>" placeholder="Contoh : PT. ABC"></td>
	</tr>
	<tr>
		<td>Harga</td>
		<td><input required type="text" name="modal" value="<?php echo e(isset($modal) ? $modal : ''); ?>" placeholder="Contoh : 20000"></td>
	</tr>
	<tr>
		<td>Satuan</td>
		<td><input required type="text" name="units" value="<?php echo e(isset($units) ? $units : ''); ?>" placeholder="Contoh : kg"></td>
	</tr>
	<tr>
		<td>Deskripsi</td>
		<td><textarea required type="text" name="description" placeholder="Contoh : Bibit yang direkomendasikan"><?php echo e(isset($description) ? $description : ''); ?></textarea></td>
	</tr>
	<tr>
		<td></td>
		<td><input type="submit" value="Simpan"></td>
	</tr>
</table>