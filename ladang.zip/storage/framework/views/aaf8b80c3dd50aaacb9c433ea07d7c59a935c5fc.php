<?php $__env->startSection('title'); ?> Semua Data Pengguna <?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<hr>
<h1>Semua Data Pengguna</h1>
<hr>
<table class="table">
	<thead>
		<tr>
			<th>Nama</th>
			<th>E-Mail</th>
			<th>Nomor HP</th>
			<th colspan="2">Action</th>
		</tr>
	</thead>
	<tbody>
	<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<tr>
			<td><?php echo e($data->name); ?></td>
			<td><?php echo e($data->email); ?></td>
			<td><?php echo e($data->phone); ?></td>
			<td><form method="POST" action="<?php echo route('user.destroy',[$data->id]); ?>">
				<input type="hidden" name="_method" value="DELETE"><?php echo e(csrf_field()); ?><input type="submit" class="delete" onclick="return confirm('Are you sure to delete user <?php echo e($data->name); ?>?')" value="Hapus"></form></td>
		</tr>		
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</tbody>
</table>

<?php echo $user->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('appadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>