<?php $__env->startSection('title'); ?> Ubah Data Petani <?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<hr><div class="pull-right"><a class="addnew" href="<?php echo e(route('material.index')); ?>">Semua Data Petani</a></div>
<h1>Ubah Data Petani</h1>
<hr>
<form method="POST" action="<?php echo e(route('material.update',[$id])); ?>">
	<?php echo e(csrf_field()); ?>

	<input type="hidden" name="_method" value="PATCH">
	<input type="hidden" name="id" value="<?php echo e($id); ?>">
	<?php echo $__env->make('admin.material._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('appadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>