<?php $__env->startSection('title'); ?> Produk Saya <?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<hr><div class="pull-right"><a class="addnew" href="<?php echo e(route('harvest.my-product')); ?>">Produk Saya</a></div>
<h1>Mulai Penanaman</h1>
<hr>
<form method="POST" action="<?php echo e(route('harvest.next-start-plant')); ?>">
<?php echo e(csrf_field()); ?>

<table class="table">
	<tr>
		<td>Produk</td>
		<td><select name="id_product" type="text">
			<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<option value="<?php echo e($key->id); ?>"><?php echo e($key->name); ?></option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		</select></td>
	</tr>
	<tr>
		<td>Mulai Penanaman</td>
		<td><input type="text" class="for_date" name="plant_date"></td>
	</tr>
	<tr>
		<td>Perkiraan Panen</td>
		<td><input type="text" class="for_date" name="harvest_date_predict"></td>
	</tr>
	<tr>
		<td></td>
		<td><input type="submit" value="Selanjutnya"></td>
	</tr>
</table>
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<script type="text/javascript">
	$(".for_date").datepicker();
	$(".for_date").datepicker("option", "dateFormat", "dd MM yy");
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('appfarmer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>