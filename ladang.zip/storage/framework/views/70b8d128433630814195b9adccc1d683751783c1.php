<?php $__env->startSection('title'); ?> Produk Saya <?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<hr><div class="pull-right"><a class="addnew" href="<?php echo e(route('harvest.my-product')); ?>">Produk Saya</a></div>
<h1>Review Penanaman</h1>
<hr>

<hr>
<strong>Data Produk</strong>
<hr>
<form method="POST" action="<?php echo e(route('harvest.next-review-plant',[$harvest->id])); ?>">
<?php echo e(csrf_field()); ?>

<table class="table" style="width:50%;">
	<tr>
		<td>Nama Produk</td>
		<td><?php echo e($harvest->product->name); ?></td>
	</tr>
	<tr>
		<td>Mulai Penanaman</td>
		<td><?php echo e(date_format(date_create($harvest->plant_date),"d F Y")); ?></td>
	</tr>
	<tr>
		<td>Perkiraan Panen</td>
		<td><?php echo e(date_format(date_create($harvest->harvest_date_predict),"d F Y")); ?></td>
	</tr>
</table>
<hr>
<strong>Data Bahan Pokok</strong>
<hr>
<table class="table">
	<thead>
		<tr>
			<th>Bahan Pokok</th>
			<th>Jumlah</th>
			<th></th>
			<th style="text-align: center">Harga Total</th>
		</tr>
	</thead>
	<tbody>
		<?php $i=0;?>
		<?php $__currentLoopData = $material; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<tr>
			<td><?php echo e($key->product->name); ?></td>
			<td><?php echo e($key->amount); ?> <?php echo e($key->units); ?></td>
			<td style="text-align: right">Rp.</td>
			<td style="text-align: right"><?php echo e(number_format($key->modal)); ?></td>
		</tr>
		<?php $i+=$key->modal;?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		<tr>
			<td></td>
			<td></td>
			<td style="text-align: right">Total Rp.</td><td style="text-align: right"><?php echo e(number_format($i)); ?></td>
		</tr>
		<tr>
			<td><a href="<?php echo e(route('harvest.cancel-plant',[$harvest->id])); ?>" class="cancelbtn">Batalkan</a></td>
			<td></td>
			<td></td>
			<td><input type="submit" value="Mulai Tanam"></td>
		</tr>
	</tbody>
</table>
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<script type="text/javascript">
	$(".for_date").datepicker();
	$(".for_date").datepicker("option", "dateFormat", "dd MM yy");
	function hitung(id) {
		if($("#amount_"+id).val()!="" && $("#price_"+id).val()!=""){
			$("#total_"+id).val($("#amount_"+id).val()*$("#price_"+id).val());
		}
	}
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('appfarmer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>