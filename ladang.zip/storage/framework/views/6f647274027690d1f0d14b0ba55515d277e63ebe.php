<?php $__env->startSection('title'); ?> Semua Data Bahan Pokok <?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<hr><div class="pull-right"><a class="addnew" href="<?php echo e(route('material.create')); ?>">Tambah Data Bahan Pokok</a></div>
<h1>Semua Data Bahan Pokok</h1>
<hr>
<table class="table">
	<thead>
		<tr>
			<th>Nama</th>
			<th>Supplier</th>
			<th>Modal</th>
			<th>Satuan</th>
			<th colspan="2">Action</th>
		</tr>
	</thead>
	<tbody>
	<?php $__currentLoopData = $material; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<tr>
			<td><?php echo e($data->name); ?></td>
			<td><?php echo e($data->supplier); ?></td>
			<td>Rp. <?php echo e(number_format($data->modal,0)); ?></td>
			<td><?php echo e($data->units); ?></td>
			<td><a class="button" href="<?php echo route('material.edit',[$data->id]); ?>">Ubah</a></td>
			<td><form method="POST" action="<?php echo route('material.destroy',[$data->id]); ?>">
				<input type="hidden" name="_method" value="DELETE"><?php echo e(csrf_field()); ?><input type="submit" class="delete" onclick="return confirm('Are you sure to delete material <?php echo e($data->name); ?>?')" value="Hapus"></form></td>
		</tr>		
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</tbody>
</table>

<?php echo $material->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('appadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>